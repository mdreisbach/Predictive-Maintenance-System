import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;


public class GUI {
	
	private static String currentFile;
	
	public static void main(String[] args)
	{
		createAndShow();
	         
	}
	
	
	
	private static void createAndShow()
	{
	
	JFrame frame = new JFrame("GUI V3.0");
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	JFrame settingsPopup = new JFrame("Settings");
	JButton importButton = new JButton("Import");
	
	JFileChooser fileSelect = new JFileChooser();
	FileFilter csv = new FileNameExtensionFilter("CSV Files", new String[] {"csv"});
	FileFilter txt = new FileNameExtensionFilter("TXT Files", new String[] {"txt"});

	fileSelect.setFileFilter(txt);
	fileSelect.setFileFilter(csv);
	
	
	JButton settingsButton = new JButton("Settings");
	JButton runButton = new JButton("Run");
	JTextField filePathText = new JTextField("Filepath");
	JTextField consoleText = new JTextField("Console");
	
	filePathText.setPreferredSize(new Dimension(500,20));
	consoleText.setPreferredSize(new Dimension(500,200));

	settingsButton.setPreferredSize(new Dimension(150,20));
	runButton.setPreferredSize(new Dimension(150,20));
	
	JPanel containerPanel = new JPanel();
	JPanel fileIOPanel = new JPanel();
	JPanel settingsRunPanel = new JPanel();
	
	fileIOPanel.setLayout(new BorderLayout(2,5));
	settingsRunPanel.setLayout(new BoxLayout(settingsRunPanel, BoxLayout.PAGE_AXIS));

	fileIOPanel.add(filePathText,BorderLayout.PAGE_START);
	fileIOPanel.add(importButton,BorderLayout.CENTER);
	

	//settingsRunPanel.add(settingsButton,BorderLayout.SOUTH);
	//settingsRunPanel.add(runButton,BorderLayout.SOUTH);
	
	fileIOPanel.add(settingsButton,BorderLayout.LINE_START);
	fileIOPanel.add(runButton,BorderLayout.LINE_END);
	fileIOPanel.add(consoleText, BorderLayout.SOUTH);

	containerPanel.add(fileIOPanel);
	containerPanel.add(settingsRunPanel);
	
	frame.setSize(600,320);
	frame.add(containerPanel);
	//frame.pack();
	frame.setVisible(true);
	
	settingsPopup.setSize(320,240);
	
	
	
	
	
	
	importButton.addActionListener( new ActionListener()
	{

		@Override
		public void actionPerformed(ActionEvent e) {
			
			//settingsPopup.setVisible(true);
			int result;
			
			String filePath = "";
			
			result = fileSelect.showOpenDialog(null);
			if(result == JFileChooser.APPROVE_OPTION) {
			filePath = fileSelect.getSelectedFile().getAbsolutePath();
			filePathText.setText(filePath);
			setCurrentFile(filePath);
			System.out.println("The current filepath is " + getCurrentFile());
			}
		}});
	
	settingsButton.addActionListener( new ActionListener()
		{

		@Override
		public void actionPerformed(ActionEvent e) {
			
			settingsPopup.setVisible(true);	
			}
		});
	
	
	runButton.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			
			System.out.println("The Run button has been pressed.");
			}
	});
	
		
	}
	//End buildAndRun

	
	
	public static void setCurrentFile(String s)
	{
		currentFile = s;
	}
	
	public static String getCurrentFile()
	{
		return currentFile;
	}
	
	
}
			
		
			
	
	
	
