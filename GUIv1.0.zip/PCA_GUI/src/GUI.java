import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class GUI {
	
	private static void createAndShow()
	{
	JFrame frame = new JFrame("GUI V1.0");
	JFrame fileIOPopup = new JFrame("File Select");
	JButton importButton = new JButton("Import");
	
	JFileChooser fileSelect = new JFileChooser();
	JButton settingsButton = new JButton("Settings");
	JButton runButton = new JButton("Run");
	JTextField filePathText = new JTextField("Filepath");
	
	JPanel containerPanel = new JPanel();
	JPanel fileIOPanel = new JPanel();
	JPanel settingsRunPanel = new JPanel();
	
	fileIOPanel.setLayout(new BoxLayout(fileIOPanel, BoxLayout.PAGE_AXIS));
	settingsRunPanel.setLayout(new BoxLayout(settingsRunPanel, BoxLayout.PAGE_AXIS));

	fileIOPanel.add(filePathText);
	fileIOPanel.add(importButton);
	

	settingsRunPanel.add(settingsButton);
	settingsRunPanel.add(runButton);
	

	containerPanel.add(fileIOPanel);
	containerPanel.add(settingsRunPanel);
	
	frame.setSize(400,200);
	frame.add(containerPanel);
	//frame.pack();
	frame.setVisible(true);
	
	fileIOPopup.setSize(800,400);
	fileIOPopup.add(fileSelect);
	
	importButton.addActionListener( new ActionListener()
	{

		@Override
		public void actionPerformed(ActionEvent e) {
			
			fileIOPopup.setVisible(true);

			
		}
	});
	
	}
	
	public static void main(String[] args)
	{
		 javax.swing.SwingUtilities.invokeLater(new Runnable() {
	            public void run() {
	                createAndShow();
	            }
	        });
	    }
	}
	
	
