package v1;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.lang.ProcessBuilder;

public class MatlabExecutor {
	
	public MatlabExecutor(String File_Path) {
		try {
			
			Process p = Runtime.getRuntime().exec(File_Path);
	        p.waitFor();
			
//			ProcessBuilder p = new ProcessBuilder();
//			p.command(File_Path);
				
			System.out.println("Starting Matlab");
//			p.start();
			
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
