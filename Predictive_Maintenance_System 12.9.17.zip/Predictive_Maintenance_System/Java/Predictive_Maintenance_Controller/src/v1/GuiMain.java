package v1;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

public class GuiMain {

	private String currentFile;

	public GuiMain() {
		
		createAndShow();

	}

	private void createAndShow() {

		JFrame frame = new JFrame("Predictive Maintenance System - Team Elephants");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		

		//Set the file types that the user can browse for
		//Only allow CSV right now
		JFileChooser fileSelect = new JFileChooser();
		FileFilter csv = new FileNameExtensionFilter("CSV Files", new String[] { "csv" });

		fileSelect.setFileFilter(csv);

		//Setting up buttons and textfield for filepath
		JButton browseButton = new JButton("Browse");
		JButton settingsButton = new JButton("Settings");
		JButton runButton = new JButton("Run");
		JTextField filePathText = new JTextField("Filepath");
		JTextField consoleText = new JTextField("Console");

		consoleText.setPreferredSize(new Dimension(500, 200));
		filePathText.setPreferredSize(new Dimension(500, 20));
		settingsButton.setPreferredSize(new Dimension(150, 20));
		runButton.setPreferredSize(new Dimension(150, 20));

		JPanel containerPanel = new JPanel();
		JPanel fileIOPanel = new JPanel();
		JPanel settingsRunPanel = new JPanel();

		fileIOPanel.setLayout(new BorderLayout(2, 5));
		settingsRunPanel.setLayout(new BoxLayout(settingsRunPanel, BoxLayout.PAGE_AXIS));

		fileIOPanel.add(filePathText, BorderLayout.PAGE_START);
		fileIOPanel.add(runButton, BorderLayout.CENTER);

		fileIOPanel.add(browseButton, BorderLayout.LINE_START);
		fileIOPanel.add(settingsButton, BorderLayout.LINE_END);
		fileIOPanel.add(consoleText, BorderLayout.SOUTH);

		containerPanel.add(fileIOPanel);
		containerPanel.add(settingsRunPanel);

		frame.setSize(620, 300);
		frame.add(containerPanel);
		// frame.pack();
		frame.setVisible(true);

		browseButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				// settingsPopup.setVisible(true);
				int result;

				String filePath = "";

				result = fileSelect.showOpenDialog(null);
				if (result == JFileChooser.APPROVE_OPTION) {
					filePath = fileSelect.getSelectedFile().getAbsolutePath();
					filePathText.setText(filePath);
					setCurrentFile(filePath);
					System.out.println("The current filepath is " + getCurrentFile());
				}
			}
		});

		settingsButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				GuiSettings guiSettings = new GuiSettings();
			}
		});

		runButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				System.out.println("The Run button has been pressed.");
				
				//Preprocess data
				PreprocessController pc1 = new PreprocessController(getCurrentFile());

				//Perform PCA on data
				PrincipalComponentAnalyzer pca = new PrincipalComponentAnalyzer();
				
				//Pass full PCA data set into the Trained Model
				TrainedModel model = new TrainedModel();
				
				//Create the web based output
				OutputGenerator output = new OutputGenerator();
				
			}
		});

	}
	// End buildAndRun

	public void setCurrentFile(String s) {
		this.currentFile = s;
	}

	public String getCurrentFile() {
		return this.currentFile;
	}

}
