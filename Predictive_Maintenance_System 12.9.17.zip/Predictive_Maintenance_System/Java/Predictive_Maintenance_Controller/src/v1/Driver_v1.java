package v1;

public class Driver_v1 {

	public static void main(String[] args) {

//		OutputGenerator output = new OutputGenerator();
//		String outputHtml = output.htmlTableGenerator("C:\\Users\\connorlof\\Documents\\School\\Fall 2017\\Software Eng\\Predictive_Maintenance_System\\Files\\Classification_Tables\\dataMeasurement9.csv");
//
//		System.out.println(outputHtml);
		
		GuiMain guiMain = new GuiMain();
		

	}

}
