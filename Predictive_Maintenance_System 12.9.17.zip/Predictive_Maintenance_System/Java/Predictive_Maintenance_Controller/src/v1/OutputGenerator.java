package v1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class OutputGenerator {
	
	public OutputGenerator(){
		
		//Class to format and open web browser compatible output
		//Either load MATLAB graph or use JS graph
		//Will format CSV to HTML table
		//Will replace parts of Bootstrap template with generated code
		
		
		
	}
	
	public String htmlTableGenerator(String csvFile){
		
		String htmlTableOutput = "";
		ArrayList<String> rowList = new ArrayList();
		String lineBreak = System.lineSeparator();
		
		//Read CSV file line by line into ArrayList
		try(BufferedReader br = new BufferedReader(new FileReader(csvFile))) {

			
	        String line = "";
	        while ((line = br.readLine()) != null) {
	        	
	        	//Add line to the List
	        	rowList.add(line);
	        }
	    } catch (IOException e) {
	    	System.err.println("Error reading in data file.");
	        e.printStackTrace();
	    }
		
		//Loop through Arraylist of data and create HTML Table Code
		for (int i = 0; i < rowList.size(); i++){
			
			htmlTableOutput = htmlTableOutput + "<tr>" + lineBreak;
			
			//Split row by comma
			String[] splitData = rowList.get(i).split(",");
			
			//Loop through each element in the row
			for (int j = 0; j < splitData.length; j++){
				
				htmlTableOutput = htmlTableOutput + "<td>" + splitData[j] + "</td>" + lineBreak;
				
			}
			
			htmlTableOutput = htmlTableOutput + "</tr>" + lineBreak;
			
		}
		
		return htmlTableOutput;
		
	}

}
