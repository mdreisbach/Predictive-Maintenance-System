package v1;

public class TrainedModel {
	
	public TrainedModel(){
		
		//Class to pass new data from the PrincipalComponentAnalyzer to for predictions
		//Uses MatlabExecutor to call the Trained Model Executable
		
		//Possibly add additional functionality to 
		//add data to trained model
		//generate new trained model
		
	}

}
