currentDataTable = readtable('C:\Users\connorlof\Documents\School\Fall 2017\Software Eng\Predictive_Maintenance_System\Files\Classification_Tables\dataMeasurementFull.csv','ReadVariableNames',true);


dataAsArray = table2array(currentDataTable);