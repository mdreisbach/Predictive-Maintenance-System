import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class GUI {
	
	private static String currentFile;
	
	public static void main(String[] args)
	{
		createAndShow();
	         
	}
	
	
	
	private static void createAndShow()
	{
	
	JFrame frame = new JFrame("GUI V1.0");
	JFrame fileIOPopup = new JFrame("File Select");
	JButton importButton = new JButton("Import");
	
	JFileChooser fileSelect = new JFileChooser();
	JButton settingsButton = new JButton("Settings");
	JButton runButton = new JButton("Run");
	JTextField filePathText = new JTextField("Filepath");
	
	filePathText.setSize(20,500);
	
	JPanel containerPanel = new JPanel();
	JPanel fileIOPanel = new JPanel();
	JPanel settingsRunPanel = new JPanel();
	
	fileIOPanel.setLayout(new BorderLayout());
	settingsRunPanel.setLayout(new BoxLayout(settingsRunPanel, BoxLayout.PAGE_AXIS));

	fileIOPanel.add(filePathText,BorderLayout.NORTH);
	fileIOPanel.add(importButton,BorderLayout.NORTH);
	

	settingsRunPanel.add(settingsButton,BorderLayout.SOUTH);
	settingsRunPanel.add(runButton,BorderLayout.SOUTH);
	

	containerPanel.add(fileIOPanel);
	containerPanel.add(settingsRunPanel);
	
	frame.setSize(600,400);
	frame.add(containerPanel);
	//frame.pack();
	frame.setVisible(true);
	
	fileIOPopup.setSize(1200,600);
	fileIOPopup.add(fileSelect);
	
	
	
	
	
	importButton.addActionListener( new ActionListener()
	{

		@Override
		public void actionPerformed(ActionEvent e) {
			
			//fileIOPopup.setVisible(true);
			int result;
			
			String filePath = "";
			
			result = fileSelect.showOpenDialog(null);
			if(result == JFileChooser.APPROVE_OPTION) {
			filePath = fileSelect.getSelectedFile().getAbsolutePath();
			filePathText.setText(filePath);
			setCurrentFile(filePath);
			System.out.println("The current filepath is " + getCurrentFile());
			}
		}});
		
		
	
	}
	
	public static void setCurrentFile(String s)
	{
		currentFile = s;
	}
	
	public static String getCurrentFile()
	{
		return currentFile;
	}
	
	
}
			
		
			
	
	
	
